package com.example.atlantis

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast

import com.firebase.ui.auth.AuthUI
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import java.util.*


class LoginFragment : AppCompatActivity() {
    private lateinit var mFirebaseAuth: FirebaseAuth
    private lateinit var mAuthStateListener: FirebaseAuth.AuthStateListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = Intent(this, MainActivity::class.java)
        setContentView(R.layout.activity_login_fragment)
        mFirebaseAuth=FirebaseAuth.getInstance()
        mAuthStateListener=object: FirebaseAuth.AuthStateListener{
                override fun onAuthStateChanged(firebaseAuth: FirebaseAuth) {
                    val user = firebaseAuth.getCurrentUser() as? FirebaseUser
                    if (user != null) {
                        // User is signed in

                        startActivity(intent)
                    } else {
                        // User is signed out

                        startActivityForResult(
                            AuthUI.getInstance()
                                .createSignInIntentBuilder()
                                .setAvailableProviders(
                                    Arrays.asList(

                                        AuthUI.IdpConfig.GoogleBuilder().build()))
                                .build(),
                            LoginFragment.RC_SIGN_IN)
                    }
                }

        }
    }

    override fun onResume() {
        super.onResume()
        mFirebaseAuth.addAuthStateListener(mAuthStateListener)
    }
    override fun onPause() {
        super.onPause()
        if (mAuthStateListener != null) {
           mFirebaseAuth.removeAuthStateListener(mAuthStateListener);
        }

    }

    companion object {
        const val RC_SIGN_IN = 1
    }
}
