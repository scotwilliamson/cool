package com.example.atlantis

class ShoppingItem {
    var favourite: Boolean? = null
    var name: String? = null
    var photoUrl: String? = null
    var rating:Int?=null
    var price:Int?=null
    var quantity:Int?=null
    var description:String?=null

    constructor() {}
    constructor(favourite: Boolean?, name: String?, photoUrl: String?, rating:Int?,price:Int?,quantity:Int?,description:String) {
        this.favourite = favourite
        this.name = name
        this.photoUrl = photoUrl
        this.rating=rating
        this.price=price
        this.quantity=quantity
        this.description=description
    }

}