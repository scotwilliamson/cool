package com.example.atlantis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import com.firebase.ui.auth.AuthUI
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import java.util.*

class MainActivity : AppCompatActivity() {
    private val Sign_Out_Timer:Long = 1000

    //val goBack=Intent(this, LoginFragment::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {


        //val goBack =Intent(this, LoginFragment::class.java)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = getMenuInflater()
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val intent=Intent(this,LoginFragment::class.java)
        return when (item?.itemId) {
            R.id.sign_out_menu -> {

                AuthUI.getInstance().signOut(this).addOnCompleteListener{

                    startActivity(intent)

                }
                true
               /* Handler().postDelayed({
                    // This method will be executed once the timer is over
                    // Start your app main activity



                    // close this activity
                    finish()
                }, Sign_Out_Timer)

                */

            }
            else -> super.onOptionsItemSelected(item)
        }

    }




}
